JCL DUnit testing
=================

Requires the DUnit project ("Xtreme Unit Testing for Delphi"), available from 
http://sourceforge.net/projects/dunit/
or you can use the one shipping with Delphi.

There are two test projects:

* JclTests.dpr  - VCL project

You need to make directory "dunit/src/" available on the search path for 
these projects to compile.
