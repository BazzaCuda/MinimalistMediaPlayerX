-------------------------------------------------------------------------------
* DELPHI OPEN SOURCE TOOLS 0.5.4                                              *
-------------------------------------------------------------------------------

License:
--------

Mozilla Public License Ver. 1.1
You may obtain a copy of the License at http://www.mozilla.org/MPL/

Software distributed under the License is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
the specific language governing rights and limitations under the License.


Source code:
------------

The source code of these tools is intended for Delphi 5.01 (Update Pack #1 is
*required* due some fixes in the VCL) or Delphi 6.02. You will also need JEDI 
Code Libary:

Delphi Tools     :  http://www.volweb.cz/pvones/delphi
JEDI Code Library:  http://delphi-jedi.org/Jedi:CODELIBJCL
