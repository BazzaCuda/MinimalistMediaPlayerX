Pascal PreProcessor v0.5.1

Copyright (c) 2001 Barry Kelly.
barry_j_kelly@hotmail.com

Syntax:
  ppp.exe [options] <input files>...

Options:
  -h, -?   This help
  -i       Process includes
  -c       Process conditional directives
  -C       Strip comments
  -pxxx    Add xxx to include path
  -dxxx    Define xxx as a preprocessor conditional symbol

Preprocessed files will be written to new files with extension .pi
If you have any suggestions or bug-reports, contact me at
barry_j_kelly@hotmail.com

